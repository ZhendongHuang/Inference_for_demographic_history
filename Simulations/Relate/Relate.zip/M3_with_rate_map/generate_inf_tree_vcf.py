import argparse
import os
import re
import numpy as np
import stdpopsim

import statistics
import msprime
from IPython.display import SVG, display
import tsinfer
import scipy
import math
import numpy
import tskit
import io
import builtins
import sys
from tqdm.notebook import tqdm
from tskit import MISSING_DATA
import pickle
import random
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import cvxopt as opt
from cvxopt import matrix, spmatrix, sparse
from cvxopt.solvers import qp, options
from cvxopt import blas
from cvxopt import spdiag
import statsmodels
from statsmodels.nonparametric.kernel_regression import KernelReg
from scipy.signal import savgol_filter
import time
import bisect

seq_len = 10**7
sam_size = 100
pop_size = 2500
# r = 1*10**(-8)
epsilon = 0.00001
gene_conver = 10**(-8)
track_len = 100
# mu = 1.3*10**(-8)


r_map = msprime.RateMap(
    position=[0, 10**6, 2*10**6, 3*10**6, 4*10**6, 5*10**6, 6*10**6, 7*10**6, 8*10**6, 9*10**6, 10*10**6],
    rate=[0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8)\
         , 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8)]
)

mu_map = msprime.RateMap(
    position=[0,  2*10**6,  4*10**6,  6*10**6, 8*10**6,  10*10**6],
    rate=[0.7*10**(-8), 1*10**(-8), 1.3*10**(-8), 1.6*10**(-8), 1.9*10**(-8)]
)

demo_model = msprime.Demography.isolated_model([pop_size], growth_rate=[-0.0003])
demo_model.add_population_parameters_change(3000,  initial_size=None, growth_rate=-0.00008, population=None)
demo_model.add_population_parameters_change(9000,  initial_size=None, growth_rate=-0.00004, population=None)
demo_model.add_population_parameters_change(18000,  initial_size=None, growth_rate=-0.00002, population=None)
demo_model.add_population_parameters_change(30000,  initial_size=None, growth_rate=0, population=None)

ts = msprime.sim_ancestry(
    samples=sam_size,
    recombination_rate= r_map, 
    sequence_length= seq_len,
#             population_size = pop_size,
    gene_conversion_rate = gene_conver ,
    gene_conversion_tract_length = track_len,
    #random_seed = seed,
#         discrete_genome=False,
    demography = demo_model
    )
# Visualise the simulated ancestral history.
#SVG(ts.draw_svg())

#ts.num_trees


mts = msprime.sim_mutations(ts, rate = mu_map,
#                            discrete_genome=False,
                            #random_seed=seed
                           )

#print(iter,"done generating")


sample_data = tsinfer.SampleData.from_tree_sequence(mts, use_sites_time=False, use_individuals_time=None)

#############################################################################
newdata = tsinfer.SampleData()

gtypetable1 = sample_data.sites_genotypes 
gtypetable = gtypetable1[0:len(gtypetable1)]
gtypetable = gtypetable.astype("int")

alletable1 = sample_data.sites_alleles 
alletable = alletable1[0:len(alletable1)]

posittable1 = sample_data.sites_position 
posittable = posittable1[0:len(posittable1)]

for i in range(len(sample_data.sites_position) - 1):
    alle = alletable[i]
    posit = posittable[i]
    posit1 = posittable[i+1]
    gtype = gtypetable[i].tolist()
    newdata.add_site(position = posit, genotypes = gtype,alleles = alle)

    numerror = numpy.random.poisson( (posit1-posit)*2*sam_size*epsilon )
    locerror = numpy.sort(numpy.floor(numpy.random.uniform(posit, posit1-0.000000001,numerror) )  ) .tolist()

    curloc = posit
    for j in range(len(locerror)):
        if locerror[j] > curloc:
            curloc = locerror[j]
            gtype = numpy.zeros(2*sam_size  )
            gtype[int( numpy.random.uniform(0,2*sam_size-0.00001)   ) ] = 1
            gtype = gtype.astype('int').tolist()


            newdata.add_site(position = curloc, genotypes = gtype,alleles = ['A','T'])

alle = alletable[-1]
posit = posittable[-1]
gtype = gtypetable[-1].tolist()
newdata.add_site(position = posit, genotypes = gtype,alleles = alle)


newdata.finalise()

sample_data=newdata


inferred_ts = tsinfer.infer(sample_data,path_compression=False)

with open("infts.vcf", "w") as vcf_file:
    inferred_ts.write_vcf(vcf_file)    