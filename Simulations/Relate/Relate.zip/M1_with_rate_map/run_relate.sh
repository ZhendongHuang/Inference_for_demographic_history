#!/bin/bash

python ./generate_inf_tree_vcf.py

../bin/RelateFileFormats --mode ConvertFromVcf --haps infts_haps.haps --sample infts_sample.sample -i infts

s_time=$(date +%s)

PATH_TO_RELATE="../"

${PATH_TO_RELATE}/bin/Relate --mode All \
	--haps ./infts_haps.haps \
	--sample ./infts_sample.sample \
	--map ./recom_map.txt \
	-N 20000 \
	-m 1.3e-8 \
	-o infts_relate 

${PATH_TO_RELATE}/scripts/EstimatePopulationSize/EstimatePopulationSize.sh \
	-i infts_relate \
	-o infts_bypop \
	-m 1.3e-8 \
	--poplabels ./infts.poplabels \
	--years_per_gen 28 



e_time=$(date +%s)
time="$(( $e_time - $s_time ))"

echo "$time $(cat system_time_file.txt )" > system_time_file.txt