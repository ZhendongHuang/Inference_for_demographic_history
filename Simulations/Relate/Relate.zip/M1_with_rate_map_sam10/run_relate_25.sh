#!/bin/bash

> system_time_file.txt
chmod +x ./*

for i in `seq 1 25`
do
    ./run_relate.sh
    mv pop_size.RData pop_size_${i}_M1_sam10_withmapunknown.RData
    echo ${i}
done