import statistics
import msprime
from IPython.display import SVG, display
import tsinfer
import scipy
import math
import numpy
import tskit
import io
import builtins
import sys
from tqdm.notebook import tqdm
from tskit import MISSING_DATA
import pickle
import random
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LassoLarsIC
import matplotlib.pyplot as plt
import cvxopt as opt
from cvxopt import matrix, spmatrix, sparse
from cvxopt.solvers import qp, options
from cvxopt import blas
from cvxopt import spdiag
import statsmodels
from statsmodels.nonparametric.kernel_regression import KernelReg
from scipy.signal import savgol_filter
import mushi
import pyreadr



for i in range(1,26):

    pdata = pyreadr.read_r('pop_size_'+str(i)+'_M5_sam10_withmapunknown.RData')

    invest = pdata['pop_size'].time/28
    Ntlist = pdata['pop_size'].pop_size*2
    
    invest = numpy.array(invest)
    invest = [0]+numpy.log(invest[1:]).tolist()
    invest = numpy.array(invest)


    px = []
    py = []
    for j in range(len(invest)-1):
        px.append(invest[j])
        px.append(invest[j+1])
        py.append(Ntlist[j])
        py.append(Ntlist[j])

    plt.plot(px,py)


    
xx1 = [0,numpy.log(300)]
yy1 = [40000,40000]
xx2 = [numpy.log(300),numpy.log(400)]
yy2 = [40000,9862]
xx3 = [numpy.log(400),numpy.log(1800)]
yy3 = [9862,9862]
xx4 = [numpy.log(1800),numpy.log(1900)]
yy4 = [9862,32748]
xx5 = [numpy.log(1900),numpy.log(18000)]
yy5 = [32748,32748]
xx6 = [numpy.log(18000),numpy.log(18900)]
yy6 = [32748,19862]
xx7 = [numpy.log(18900),11]
yy7 = [19862,19862]




plt.plot(xx1,yy1,'k--',linewidth = 4, label="Model 5")
plt.plot(xx2,yy2,'k--',linewidth = 4)
plt.plot(xx3,yy3,'k--',linewidth = 4)
plt.plot(xx4,yy4,'k--',linewidth = 4)
plt.plot(xx5,yy5,'k--',linewidth = 4)
plt.plot(xx6,yy6,'k--',linewidth = 4)
plt.plot(xx7,yy7,'k--',linewidth = 4)
plt.xlim(numpy.log(50),11)
plt.ylim(0,50000) 


# plt.legend(loc="lower right",fontsize = 28)
# plt.ylabel(r"$N(g)$",fontsize =28)
plt.xlabel("Generations ago",fontsize=28)
plt.xticks(numpy.log(numpy.array([60, 400, 3000, 30000]) ),[60, 400, r'$3\,000$', r'$30\,000$'],fontsize=20)
# plt.xticks([0, 10000,20000,30000,40000],[0,r'$10\,000$',r'$20\,000$',r'$30\,000$',r'$40\,000$'],fontsize=20)
plt.yticks([0,10000,20000,30000,40000,50000],[])
# plt.yticks([0,10000,20000,30000,40000,50000],[0,r'$10\,000$',r'$20\,000$',r'$30\,000$',r'$40\,000$',r'$50\,000$'],fontsize=20)

# plt.title("Relate",fontsize=16)



## epsilon = 0.00005
## with map