import statistics
import msprime
from IPython.display import SVG, display
import tsinfer
import scipy
import math
import numpy
import tskit
import io
import builtins
import sys
from tqdm.notebook import tqdm
from tskit import MISSING_DATA
import pickle
import random
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LassoLarsIC
import matplotlib.pyplot as plt
import cvxopt as opt
from cvxopt import matrix, spmatrix, sparse
from cvxopt.solvers import qp, options
from cvxopt import blas
from cvxopt import spdiag
import statsmodels
from statsmodels.nonparametric.kernel_regression import KernelReg
from scipy.signal import savgol_filter
import mushi
import time



import bisect
def find_s(elem, sorted_list):
    'Locate the leftmost value exactly equal to x'
    i = bisect.bisect_left(sorted_list, elem)
    if i != len(sorted_list) and sorted_list[i] == elem:
        return i


def find_s_se(elem, sorted_list):
    'Locate the leftmost value smaller or equal to x'
    i = bisect.bisect_right(sorted_list, elem)
    if i != 0:
        return i-1
    else:
        print("error")


def find_s_s(elem, sorted_list):
    'Locate the leftmost value smaller or equal to x'
    i = bisect.bisect_left(sorted_list, elem)
    if i != 0:
        return i
    else:
        return 0




seq_len = 10**7
sam_size = 100



epsilon = 0.00001
gene_conver = 10**(-8)
track_len = 100

numchromosome = 1

totaliter=25





r_map = msprime.RateMap(
    position=[0, 10**6, 2*10**6, 3*10**6, 4*10**6, 5*10**6, 6*10**6, 7*10**6, 8*10**6, 9*10**6, 10*10**6],
    rate=[0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8)\
         , 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8)]
)

mu_map = msprime.RateMap(
    position=[0,  2*10**6,  4*10**6,  6*10**6, 8*10**6,  10*10**6],
    rate=[0.7*10**(-8), 1*10**(-8), 1.3*10**(-8), 1.6*10**(-8), 1.9*10**(-8)]
)



pop_size = 20000
demo_model = msprime.Demography.isolated_model([pop_size], growth_rate=[0])
demo_model.add_population_parameters_change(300,  initial_size=None, growth_rate= 0.014, population=None)
demo_model.add_population_parameters_change(400,  initial_size=None, growth_rate= 0, population=None)
demo_model.add_population_parameters_change(1800,  initial_size=None, growth_rate= -0.012, population=None)
demo_model.add_population_parameters_change(1900,  initial_size=None, growth_rate= 0, population=None)
demo_model.add_population_parameters_change(18000,  initial_size=None, growth_rate= 0.005, population=None)
demo_model.add_population_parameters_change(18100,  initial_size=None, growth_rate= 0, population=None)



lamd = []
Ntlist = []

sum_time = 0
for it in range(totaliter):

    for chromosome in range(numchromosome):
#         seed = chromosome + 1

        ts = msprime.sim_ancestry(
            samples=sam_size,
            recombination_rate= r_map, 
            sequence_length= seq_len,
#             population_size = pop_size,
            gene_conversion_rate = gene_conver ,
            gene_conversion_tract_length = track_len,
            #random_seed = seed,
    #         discrete_genome=False,
            demography = demo_model
            )
    
        # Visualise the simulated ancestral history.
        #SVG(ts.draw_svg())

        #ts.num_trees


        mts = msprime.sim_mutations(ts, rate = mu_map,
                                    discrete_genome=False,
                                    #random_seed=seed
                                   )

        #print(iter,"done generating")

        print('done1')

        sample_data = tsinfer.SampleData.from_tree_sequence(mts, use_sites_time=False, use_individuals_time=None)
        #inferred_ts = tsinfer.infer(sample_data,path_compression=False)

        
        #############################################################################
        newdata = tsinfer.SampleData()

        gtypetable1 = sample_data.sites_genotypes 
        gtypetable = gtypetable1[0:len(gtypetable1)]
        gtypetable = gtypetable.astype("int")

        alletable1 = sample_data.sites_alleles 
        alletable = alletable1[0:len(alletable1)]

        posittable1 = sample_data.sites_position 
        posittable = posittable1[0:len(posittable1)]

        for i in range(len(sample_data.sites_position) - 1):
            alle = alletable[i]
            posit = posittable[i]
            posit1 = posittable[i+1]
            gtype = gtypetable[i].tolist()
            newdata.add_site(position = posit, genotypes = gtype,alleles = alle)

            numerror = numpy.random.poisson( (posit1-posit)*2*sam_size*epsilon )
            locerror = numpy.sort(numpy.floor(numpy.random.uniform(posit, posit1-0.000000001,numerror) )  ) .tolist()

            curloc = posit
            for j in range(len(locerror)):
                if locerror[j] > curloc:
                    curloc = locerror[j]
                    gtype = numpy.zeros(2*sam_size  )
                    gtype[int( numpy.random.uniform(0,2*sam_size-0.00001)   ) ] = 1
                    gtype = gtype.astype('int').tolist()


                    newdata.add_site(position = curloc, genotypes = gtype,alleles = ['A','T'])

        alle = alletable[-1]
        posit = posittable[-1]
        gtype = gtypetable[-1].tolist()
        newdata.add_site(position = posit, genotypes = gtype,alleles = alle)


        newdata.finalise()
        
        sample_data=newdata


        print('done2')
        
        ###############################################

        ggg = sample_data.sites_genotypes 
        genes = ggg[0:len(ggg)].T
        print("don3")
        genes = genes.astype("int")
        print("don4",it)
        mufreq_obs = sum(genes>0)




        #########################################################################################



        sortfreq_obs = numpy.sort(mufreq_obs)
        curstart= 0 
        curind = 0
        curfreq= sortfreq_obs[curind]
        sfsv = numpy.zeros(2*sam_size-1)

        while curind <= len(sortfreq_obs)-1:
            if sortfreq_obs[curind] == curfreq:
                curind = curind+1
            else:
                sfsv[ int(curfreq)-1 ] = (curind - curstart)
                curstart = curind
                curfreq = sortfreq_obs[curind]

            if curind == len(sortfreq_obs):
                sfsv[ int(curfreq)-1 ] = (curind - curstart)

        s_time = time.time()        

        ksfs = mushi.kSFS(X=sfsv)
        ksfs.infer_eta(1.3*10**(-8)*seq_len,
                       (0,20),  # <-- trend penalty  (can take 5)
                       pts = 20,  # number interval
                       ta = 60000,  # max time
                       max_iter=300,
#                        loss ='lsq',
                       verbose=True)

############################################################################################
############################################################################################

#         ksfs.eta.plot(label='inferred')
#         plt.legend();

        



        invest = ksfs.eta.arrays()[0]
        Ntlist = ksfs.eta.arrays()[1]
        
        
        e_time = time.time()
        
        name = "Mushi_M5_pop_" +str(it)+".dat"
        file = open(name,"wb") 
        pickle.dump(Ntlist,file)
        file.close()

        name = "Mushi_M5_gen_" +str(it)+".dat"
        file = open(name,"wb") 
        pickle.dump(invest,file)
        file.close()
        
####################################################
        invest = numpy.array(invest)
        invest = [0]+numpy.log(invest[1:]).tolist()
        invest = numpy.array(invest)

        
        px = []
        py = []
        for j in range(len(invest)-1):
            px.append(invest[j])
            px.append(invest[j+1])
            py.append(Ntlist[j])
            py.append(Ntlist[j])

        plt.plot(px,py)

        
        sum_time = sum_time + e_time-s_time
        
        print("iteration",it)
        
ave_time = sum_time/totaliter
print("average time", ave_time)

name = "Mushi_M5_ave_time_.dat"
file = open(name,"wb") 
pickle.dump(ave_time,file)
file.close()        
    


xx1 = [0,numpy.log(300)]
yy1 = [40000,40000]
xx2 = [numpy.log(300),numpy.log(400)]
yy2 = [40000,9862]
xx3 = [numpy.log(400),numpy.log(1800)]
yy3 = [9862,9862]
xx4 = [numpy.log(1800),numpy.log(1900)]
yy4 = [9862,32748]
xx5 = [numpy.log(1900),numpy.log(18000)]
yy5 = [32748,32748]
xx6 = [numpy.log(18000),numpy.log(18900)]
yy6 = [32748,19862]
xx7 = [numpy.log(18900),11]
yy7 = [19862,19862]




plt.plot(xx1,yy1,'k')
plt.plot(xx2,yy2,'k')
plt.plot(xx3,yy3,'k')
plt.plot(xx4,yy4,'k')
plt.plot(xx5,yy5,'k')
plt.plot(xx6,yy6,'k')
plt.plot(xx7,yy7,'k')
plt.xlim(numpy.log(50),11)
plt.ylim(0,70000) 



