import statistics
import msprime
from IPython.display import SVG, display
import tsinfer
import scipy
import math
import numpy
import tskit
import io
import builtins
import sys
from tqdm.notebook import tqdm
from tskit import MISSING_DATA
import pickle
import random
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LassoLarsIC
import matplotlib.pyplot as plt
import cvxopt as opt
from cvxopt import matrix, spmatrix, sparse
from cvxopt.solvers import qp, options
from cvxopt import blas
from cvxopt import spdiag
import statsmodels
from statsmodels.nonparametric.kernel_regression import KernelReg
from scipy.signal import savgol_filter
import mushi

# input  positions*2 gen_array, positions, seq_len, N0, mu, r     output .ms  (for a pair of sequences)

def samdata2ms(gen_array_list,position_list,seq_len,N0,r,npairs,name):
    
    # gen_array is len(poisition)*2 binary numpy.array
    # positions is a list or array collecting all mu site positions.
    # N0, initial pop_size
    # r recombination rate

    nsite = seq_len
    r1 = 2*r*nsite
    rho = 4*N0*r1
    thetams = 4*N0*2*mu*nsite

    with open(name, 'w') as f:
        f.write('./ms 2 ')
        f.write(str(npairs))
        f.write(' -t ')
        f.write(str(thetams))
        f.write(' ')
        f.write('-r ')
        f.write(str(rho))
        f.write(' ')
        f.write(str(nsite))
        f.write(' -p 10 > msfile.ms')
        f.write('\n')
        f.write('1 1 1')
        
        for j in range(npairs):
            positions = position_list[j]
            gen_array = gen_array_list[j]
            f.write('\n')
            f.write('\n')
            f.write('//')
            f.write('\n')
            f.write('segsites: ')
            f.write( str(len(positions)) )
            f.write('\n')
            f.write('positions:')
            for i in range(len(positions)):
                f.write(' ')
                f.write(str( round(positions[i]/seq_len,10)  ))
            f.write('\n')
            for i in range(len(gen_array)):
                f.write(str( int(gen_array[i][0])  ))
            f.write('\n')
            for i in range(len(gen_array)):
                f.write(str( int(gen_array[i][1])  ))




import bisect
def find_s(elem, sorted_list):
    'Locate the leftmost value exactly equal to x'
    i = bisect.bisect_left(sorted_list, elem)
    if i != len(sorted_list) and sorted_list[i] == elem:
        return i


def find_s_se(elem, sorted_list):
    'Locate the leftmost value smaller or equal to x'
    i = bisect.bisect_right(sorted_list, elem)
    if i != 0:
        return i-1
    else:
        print("error")


def find_s_s(elem, sorted_list):
    'Locate the leftmost value smaller or equal to x'
    i = bisect.bisect_left(sorted_list, elem)
    if i != 0:
        return i
    else:
        return 0


seq_len = 10**7
sam_size = 100
pop_size = 20000
r = 10**(-8)
mu = 1.3*10**(-8)
epsilon = 0.00001
gene_conver = 10**(-8)
track_len = 100






r_map = msprime.RateMap(
     position=[0, 10**6, 2*10**6, 3*10**6, 4*10**6, 5*10**6, 6*10**6, 7*10**6, 8*10**6, 9*10**6, 10*10**6],
     rate=[0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8), 0.5*10**(-8)\
          , 1.5*10**(-8), 0.5*10**(-8), 1.5*10**(-8)]
)

mu_map = msprime.RateMap(
     position=[0,  2*10**6,  4*10**6,  6*10**6, 8*10**6,  10*10**6],
     rate=[0.7*10**(-8), 1*10**(-8), 1.3*10**(-8), 1.6*10**(-8), 1.9*10**(-8)]
)




demo_model = msprime.Demography.isolated_model([pop_size], growth_rate=[10**(-4)])
demo_model.add_population_parameters_change(30000,  initial_size=None, growth_rate=0, population=None)



ts = msprime.sim_ancestry(
    samples=sam_size,
    recombination_rate= r_map, 
    sequence_length= seq_len,
#    population_size = pop_size,
    gene_conversion_rate = gene_conver ,
    gene_conversion_tract_length = track_len,
#    random_seed = seed,
#    discrete_genome=False,
    demography = demo_model
    )
# Visualise the simulated ancestral history.
#SVG(ts.draw_svg())

#ts.num_trees


mts = msprime.sim_mutations(ts, rate = mu_map,
                            discrete_genome=False,
                            #random_seed=seed
                           )


print('done1')

sample_data = tsinfer.SampleData.from_tree_sequence(mts, use_sites_time=False, use_individuals_time=None)
#inferred_ts = tsinfer.infer(sample_data,path_compression=False)


#############################################################################
newdata = tsinfer.SampleData()

gtypetable1 = sample_data.sites_genotypes 
gtypetable = gtypetable1[0:len(gtypetable1)]
gtypetable = gtypetable.astype("int")

alletable1 = sample_data.sites_alleles 
alletable = alletable1[0:len(alletable1)]

posittable1 = sample_data.sites_position 
posittable = posittable1[0:len(posittable1)]

for i in range(len(sample_data.sites_position) - 1):
    alle = alletable[i]
    posit = posittable[i]
    posit1 = posittable[i+1]
    gtype = gtypetable[i].tolist()
    newdata.add_site(position = posit, genotypes = gtype,alleles = alle)

    numerror = numpy.random.poisson( (posit1-posit)*2*sam_size*epsilon )
    locerror = numpy.sort(numpy.floor(numpy.random.uniform(posit, posit1-0.000000001,numerror) )  ) .tolist()

    curloc = posit
    for j in range(len(locerror)):
        if locerror[j] > curloc:
            curloc = locerror[j]
            gtype = numpy.zeros(2*sam_size  )
            gtype[int( numpy.random.uniform(0,2*sam_size-0.00001)   ) ] = 1
            gtype = gtype.astype('int').tolist()


            newdata.add_site(position = curloc, genotypes = gtype,alleles = ['A','T'])

alle = alletable[-1]
posit = posittable[-1]
gtype = gtypetable[-1].tolist()
newdata.add_site(position = posit, genotypes = gtype,alleles = alle)


newdata.finalise()

sample_data=newdata

#########################################################################

gtypetable1 = sample_data.sites_genotypes 
gtypetable = gtypetable1[0:len(gtypetable1)]
gtypetable = gtypetable.astype("int")

####### new #######################################

npairs = 10

samuse = random.sample([*range(2*sam_size - 1)],npairs*2)

position_list = []
gen_array_list = []
for i in range(npairs):
    pair = [samuse[i],samuse[npairs+i] ]    
    gen_array = gtypetable[:,pair]    
    diff = gen_array[:,0] - gen_array[:,1]     
    nzindex = list(numpy.where(diff!=0)[0])
    positions = sample_data.sites_position[nzindex]    
    position_list.append(positions)
    gen_array = gen_array[nzindex,:]
    gen_array_list.append(gen_array)




N0 = pop_size
name = 'msfile.ms'


samdata2ms(gen_array_list,position_list,seq_len,N0,r,npairs,name=name)

###################################################

