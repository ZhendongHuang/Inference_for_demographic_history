import statistics
import msprime
from IPython.display import SVG, display
import tsinfer
import scipy
import math
import numpy
import tskit
import io
import builtins
import sys
from tqdm.notebook import tqdm
from tskit import MISSING_DATA
import pickle
import random
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LassoLarsIC
import matplotlib.pyplot as plt
import cvxopt as opt
from cvxopt import matrix, spmatrix, sparse
from cvxopt.solvers import qp, options
from cvxopt import blas
from cvxopt import spdiag
import statsmodels
from statsmodels.nonparametric.kernel_regression import KernelReg
from scipy.signal import savgol_filter
import mushi



for it in range(1,26):

        name = "pop_" + str(it) + "_M3_psmc_msprime_1sam.dat"
        file = open(name,"rb") 
        y = pickle.load(file)
        file.close()

        name = "time_" + str(it) + "_M3_psmc_msprime_1sam.dat"
        file = open(name,"rb") 
        x = pickle.load(file)
        file.close()


        invest = numpy.array(x)/25
        Ntlist = numpy.array(y)*2
        
        px = []
        py = []
        for j in range(len(invest)-1):
            px.append(invest[j])
            px.append(invest[j+1])
            py.append(Ntlist[j])
            py.append(Ntlist[j])

        plt.plot(px,py)






xx1 = numpy.linspace(0,3000,100)
yy1 = 5000*numpy.exp(xx1*(0.0003))

xx2 = numpy.linspace(3000,9000,100)
yy2 = yy1[-1]*numpy.exp( (xx2-3000)*(0.00008) )

xx3 = numpy.linspace(9000,18000,100)
yy3 = yy2[-1]*numpy.exp( (xx3-9000)* (0.00004) )

xx4 = numpy.linspace(18000,30000,100)
yy4 = yy3[-1]*numpy.exp( (xx4-18000)* (0.00002) )

xx5 = numpy.linspace(30000,45000,100)
yy5 = yy4[-1]*numpy.exp( (xx5-30000)*0 )



plt.plot(xx1,yy1,'k--',linewidth = 4, label="Model 3")
plt.plot(xx2,yy2,'k--',linewidth = 4)
plt.plot(xx3,yy3,'k--',linewidth = 4)
plt.plot(xx4,yy4,'k--',linewidth = 4)
plt.plot(xx5,yy5,'k--',linewidth = 4)
        
plt.xlim(0,40000)
plt.ylim(0,50000) 
# plt.legend(loc="upper left",fontsize = 28)
# plt.ylabel(r"$N(g)$",fontsize =28)
# plt.xlabel("Generations ago",fontsize=28)
# plt.xticks([0, 10000,20000,30000,40000],[])
plt.xticks([0, 10000,20000,30000,40000],[0,r'$10\,000$',r'$20\,000$',r'$30\,000$',r''],fontsize=20)
plt.yticks([0,10000,20000,30000,40000,50000],[])
# plt.yticks([0,10000,20000,30000,40000,50000],[0,r'$10\,000$',r'$20\,000$',r'$30\,000$',r'$40\,000$',r'$50\,000$'],fontsize=20)

# plt.title(r"PSMC (1 pair)",fontsize=32)

## epsilon = 0.00005
## with map