# ms-PSMC
Useful scripts when applying the psmc to simulated data with ms
