#!/bin/bash

> system_time_file.txt
chmod +x ./*

for i in `seq 1 25`
do
    ./run_psmc.sh
    mv example_pop.dat pop_${i}_M5_psmc_msprime_1sam.dat
    mv example_time.dat time_${i}_M5_psmc_msprime_1sam.dat
    echo ${i}
done